Team 4: Git’er Done
Assignment #5

Ryan Booth	Anthony Chow	Kaya Gajos	Tristan Sebens
75233098	71311096		62085089	46383089
h9d7		f5e7			i2u6		w6z6

File list

Sequence Diagrams
	ImportFileSQN.png
	ImportFromUrlSQN.png
	TabViewSQN.png

UML Diagram
	UML_FINAL.png
	
Bonus Question
	Bonus - Main.jpg
	Bonus - Map.jpg
	Bonus - SignIn.jpg
	
Drafts
	Draft1.pdf
	Draft2.pdf
	Draft3.jpg